import './App.css';
import Student from './Student';

function App() {
  return (
    <div className="App"> 
      <br/><br/>
      <Student name='유비'/>
      <Student name='장비'/>
      <Student name='관우'/>
    </div>
  );
}

export default App;
